const CACHE_NAME="hazbahal-farm-v1";
const CORE=["./","./index.html","./style.css","./config.js","./script.js","./manifest.json",
"./images/icon.svg","./images/farm-hero.svg","./images/field.svg","./images/maize.svg",
"./images/beans.svg","./images/vegetables.svg","./images/milk.svg","./images/eggs.svg",
"./images/chickens.svg","./images/goats.svg","./images/cattle.svg"];
self.addEventListener("install",event=>{event.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(CORE)));self.skipWaiting();});
self.addEventListener("activate",event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE_NAME).map(k=>caches.delete(k)))));self.clients.claim();});
self.addEventListener("fetch",event=>{
  if(event.request.method!=="GET")return;
  const url=new URL(event.request.url);
  if(url.origin!==location.origin)return;
  event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request).then(response=>{
    if(response&&response.status===200){const copy=response.clone();caches.open(CACHE_NAME).then(c=>c.put(event.request,copy));}
    return response;
  }).catch(()=>caches.match("./index.html"))));
});
