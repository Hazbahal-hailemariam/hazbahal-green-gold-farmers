const defaultProducts = [
  {id:"p1",name:"Maize",category:"Crops",price:"Ask for current price",description:"Quality maize, subject to seasonal availability.",image:"images/maize.svg"},
  {id:"p2",name:"Beans",category:"Crops",price:"Ask for current price",description:"Farm beans for your kitchen or business needs.",image:"images/beans.svg"},
  {id:"p3",name:"Fresh vegetables",category:"Crops",price:"Ask for current price",description:"Seasonal vegetables grown with care.",image:"images/vegetables.svg"},
  {id:"p4",name:"Fresh milk",category:"Dairy",price:"Ask for current price",description:"Enquire about milk availability and collection.",image:"images/milk.svg"},
  {id:"p5",name:"Eggs",category:"Poultry",price:"Ask for current price",description:"Fresh farm eggs. Contact us for quantities.",image:"images/eggs.svg"},
  {id:"p6",name:"Chickens",category:"Poultry",price:"Ask for current price",description:"Ask about available poultry and order sizes.",image:"images/chickens.svg"},
  {id:"p7",name:"Goats & sheep",category:"Livestock",price:"Ask for current price",description:"Enquire about livestock availability.",image:"images/goats.svg"},
  {id:"p8",name:"Cattle",category:"Livestock",price:"Ask for current price",description:"Contact the farm for current livestock details.",image:"images/cattle.svg"}
];
const $ = s => document.querySelector(s);
const read = (key,fallback) => {try{return JSON.parse(localStorage.getItem(key)) ?? fallback}catch{return fallback}};
const save = (key,value) => localStorage.setItem(key,JSON.stringify(value));
let products = read("hggf_products",defaultProducts);
let farmDetails = {...(window.FARM_CONFIG||{}),...read("hggf_details",{})};
let activeFilter = "All";

function renderProducts(){
  const shown = activeFilter==="All" ? products : products.filter(p=>p.category===activeFilter);
  $("#productGrid").innerHTML = shown.length ? shown.map(p=>`
    <article class="product-card">
      <div class="product-photo"><img src="${escapeHtml(p.image||"images/field.svg")}" alt="${escapeHtml(p.name)}" onerror="this.src='images/field.svg'"></div>
      <div class="product-info"><span class="product-category">${escapeHtml(p.category)}</span>
      <h3>${escapeHtml(p.name)}</h3><p>${escapeHtml(p.description)}</p>
      <div class="product-bottom"><span class="product-price">${escapeHtml(p.price||"Ask for price")}</span>
      <button class="small-order" data-order="${escapeHtml(p.name)}">Enquire →</button></div></div>
    </article>`).join("") : '<p class="empty-products">No products in this category yet. Please check another category.</p>';
}
function escapeHtml(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function whatsappUrl(message){
  const number=String(farmDetails.whatsapp||"").replace(/\D/g,"");
  return number ? `https://wa.me/${number}?text=${encodeURIComponent(message)}` : "";
}
function sendWhatsApp(message){
  const url=whatsappUrl(message);
  if(!url){alert("Add your WhatsApp number in Farm admin → Farm details, or update config.js before publishing.");return;}
  window.open(url,"_blank","noopener");
}
function showDetails(){
  $("#phoneDisplay").textContent=farmDetails.phone||"Add your farm phone number";
  $("#locationDisplay").textContent=farmDetails.location||"Add your farm location";
  $("#emailDisplay").textContent=farmDetails.email||"Add your farm email";
}
$("#filters").addEventListener("click",e=>{
  const b=e.target.closest("[data-filter]");if(!b)return;
  activeFilter=b.dataset.filter;
  document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderProducts();
});
$("#productGrid").addEventListener("click",e=>{
  const b=e.target.closest("[data-order]");if(b)sendWhatsApp(`Hello Hazbahal Green Gold Farmers, I am interested in ${b.dataset.order}. Please share availability and price.`);
});
$("#enquiryForm").addEventListener("submit",e=>{
  e.preventDefault();const d=Object.fromEntries(new FormData(e.currentTarget).entries());
  const message=`Farm enquiry\nName: ${d.name}\nPhone: ${d.phone}\nInterest: ${d.interest}\nMessage: ${d.message}`;
  const enquiries=read("hggf_enquiries",[]);enquiries.unshift({...d,date:new Date().toLocaleString()});save("hggf_enquiries",enquiries);
  const url=whatsappUrl(message);
  if(url){window.open(url,"_blank","noopener");$("#formHint").textContent="Your enquiry has been saved on this device and WhatsApp has been opened.";}
  else $("#formHint").textContent="Your enquiry is saved on this device. Add the farm WhatsApp number in Farm admin to send it.";
  e.currentTarget.reset();
});
$("#menuToggle").addEventListener("click",()=>{const nav=$("#mainNav");nav.classList.toggle("open");$("#menuToggle").setAttribute("aria-expanded",nav.classList.contains("open"));});
$("#mainNav").addEventListener("click",e=>{if(e.target.matches("a"))$("#mainNav").classList.remove("open");});
$("#year").textContent=new Date().getFullYear();
showDetails();renderProducts();

const dialog=$("#adminDialog");
$("#adminOpen").addEventListener("click",()=>{dialog.showModal();renderAdminProducts();populateDetails();renderEnquiries();});
$("#adminClose").addEventListener("click",()=>dialog.close());
dialog.addEventListener("click",e=>{if(e.target===dialog)dialog.close();});
document.querySelectorAll(".admin-tab").forEach(tab=>tab.addEventListener("click",()=>{
  document.querySelectorAll(".admin-tab").forEach(t=>t.classList.toggle("active",t===tab));
  document.querySelectorAll(".admin-panel").forEach(p=>p.classList.toggle("hidden",p.id!==tab.dataset.tab));
}));
function renderAdminProducts(){
  $("#adminProductList").innerHTML=products.map(p=>`<div class="admin-product-row"><span><strong>${escapeHtml(p.name)}</strong> · ${escapeHtml(p.category)} · ${escapeHtml(p.price)}</span><span><button data-edit="${p.id}">Edit</button> <button data-delete="${p.id}">Delete</button></span></div>`).join("");
}
$("#adminProductList").addEventListener("click",e=>{
  const edit=e.target.closest("[data-edit]"),del=e.target.closest("[data-delete]");
  if(edit){const p=products.find(x=>x.id===edit.dataset.edit);if(!p)return;const f=$("#productForm");Object.keys(p).forEach(k=>{if(f.elements[k])f.elements[k].value=p[k]});}
  if(del&&confirm("Delete this product from this device?")){products=products.filter(p=>p.id!==del.dataset.delete);save("hggf_products",products);renderProducts();renderAdminProducts();}
});
$("#productForm").addEventListener("submit",e=>{
  e.preventDefault();const d=Object.fromEntries(new FormData(e.currentTarget).entries());const id=d.id||"p"+Date.now();d.id=id;
  const i=products.findIndex(p=>p.id===id);if(i>=0)products[i]=d;else products.push(d);
  save("hggf_products",products);renderProducts();renderAdminProducts();e.currentTarget.reset();
});
$("#productReset").addEventListener("click",()=>setTimeout(()=>$("#productForm").elements.id.value="",0));
function populateDetails(){const f=$("#detailsForm");["whatsapp","phone","location","email"].forEach(k=>f.elements[k].value=farmDetails[k]||"");}
$("#detailsForm").addEventListener("submit",e=>{
  e.preventDefault();farmDetails={...farmDetails,...Object.fromEntries(new FormData(e.currentTarget).entries())};save("hggf_details",farmDetails);showDetails();alert("Farm details saved on this device."); 
});
function renderEnquiries(){
  const data=read("hggf_enquiries",[]);
  $("#savedEnquiries").innerHTML=data.length?data.map(x=>`<div class="enquiry-entry"><strong>${escapeHtml(x.name)}</strong> · ${escapeHtml(x.date)}<br>${escapeHtml(x.phone)} · ${escapeHtml(x.interest)}<br>${escapeHtml(x.message)}</div>`).join(""):"<p>No enquiries saved on this device yet.</p>";
}
function updateConnection(){const el=$("#connectionStatus");if(el)el.textContent=navigator.onLine?"Online • offline copy available after first visit":"Offline • viewing saved website";}
window.addEventListener("online",updateConnection);window.addEventListener("offline",updateConnection);updateConnection();
