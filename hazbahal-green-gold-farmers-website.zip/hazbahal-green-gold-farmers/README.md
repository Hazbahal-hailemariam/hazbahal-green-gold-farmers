# Hazbahal Green Gold Farmers

A mobile-friendly static farm website and installable PWA.

## Publish with GitHub Pages
1. Upload all files and the `images` folder to the root of your public repository.
2. In GitHub, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Choose branch `main` and folder `/ (root)`, then Save.
5. Wait for GitHub Pages to finish deploying.

## Configure your farm details
Edit `config.js` before publishing:
- `whatsapp`: country code and number, digits only (Kenya format example: `2547XXXXXXXX`).
- `phone`: display phone number.
- `location`: farm location.
- `email`: contact email.

Then commit the updated file to GitHub.

## Products
Default sample products are in `script.js` in the `defaultProducts` list. Edit their names, prices, descriptions and image paths before publishing.

## Admin editor limitations
The Farm admin editor stores product edits, farm details and enquiries in the current browser's local storage only. These edits are not synchronized to GitHub or other visitors. To publish changes to everyone, edit the files and upload/commit them to GitHub.

## Offline use
The service worker caches the site and included images after the first successful visit. The first visit needs internet. WhatsApp and external links require internet. Browser storage can be cleared by the device and is not a substitute for a server backup.

## Security and privacy
This is a static website. Do not collect sensitive personal information. The admin editor is not password protected and is not a secure multi-user management system. For shared product management and centralized enquiry storage, connect a backend service.
