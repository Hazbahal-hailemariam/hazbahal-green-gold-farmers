/*
  EDIT THESE DETAILS BEFORE PUBLISHING.
  WhatsApp number: country code + number, digits only. Kenya example format: 2547XXXXXXXX.
*/
window.FARM_CONFIG = {
  whatsapp: "",          // Example: "254712345678"
  phone: "Add your farm phone number",
  location: "Add your farm location, Kenya",
  email: ""
};
